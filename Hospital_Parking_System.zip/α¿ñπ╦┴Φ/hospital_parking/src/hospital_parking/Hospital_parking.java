/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital_parking;


public class Hospital_parking {

    
    public static void main(String[] args) {
        
        Menu_page menu = new Menu_page();
        menu.setVisible(true);
    }
    
}
