package hospital_parking;

import java.sql.*;

public class DB_Connect {
    
    final String DB_Url = "jdbc:mysql://localhost/hospital_parking_lot";
    final String DB_Driver = "com.mysql.jdbc.Driver";
    final String DB_User = "root";
    final String DB_Password = "";
    
    Connection con = null;
    
    public Connection DB_Connect(){
        
        try{
            
            //create bridge connection
            con = DriverManager.getConnection(DB_Url,DB_User,DB_Password);
            System.out.println("Database Connected");
            return con;
        }
        catch(SQLException e){
            
            System.out.println(e.toString());
            return null;
        }
    }
}
